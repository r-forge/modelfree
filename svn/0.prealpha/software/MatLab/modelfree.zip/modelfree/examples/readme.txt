IMF - 17/10/2008

Datasets are for the same seven examples used in paper by Zychaluk, K. and Foster, D. H.
Model-free estimation of the psychometric function (under review).

The variables are the same for all MatLab files:

x is stimulus level
r is number of successes
m is number of trials